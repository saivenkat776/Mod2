package com.capgemini.pizzaorder.ui;

import java.sql.Connection;
import java.sql.DriverManager;

	public class ConnectionsCom {	
		public static Connection getcon() {
			Connection c=null;
			try
			{
				Class.forName("oracle.jdbc.OracleDriver");
				c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg632","training632");
				System.out.println("connected");
			}
			catch(Exception e) {
				System.out.println(e);
			}
			return c;
		}

	}
