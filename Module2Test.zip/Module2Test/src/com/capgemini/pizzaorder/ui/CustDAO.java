package com.capgemini.pizzaorder.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.capgemini.pizzaorder.bean.CustBean;

public class CustDAO {
	Connection cn;
	PreparedStatement pst;
	Scanner sc=new Scanner(System.in);
	
	public void insert(CustBean obj)
	{
		
		try {
		cn=ConnectionsCom.getcon();
	    pst=cn.prepareStatement("insert into Customer_Details values(customerSeq.NEXTVAL,?,?,?)");
	    pst.setString(1, obj.getName());
	    pst.setString(2, obj.getAddress());
	    pst.setDouble(3, obj.getPhonenumber());
    	pst.executeUpdate();
    	
    	String sqlIdentifier = "select customerSeq.NEXTVAL as NEXTVAL from dual";
    	System.out.println("Order successfully placed with Order Id: "+sqlIdentifier);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public void Display()
	{
		
}
}
