package com.capgemini.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.pizzaorder.bean.CustBean;
import com.capgemini.pizzaorder.bean.VegToppings.vegToppings;
public class Client {
	static vegToppings tops;
	
	public static void main(String[] args) {
		float total=0;
		LocalDate date=LocalDate.now();
		CustDAO cust1=new CustDAO();
		Scanner sc=new Scanner(System.in);
		Scanner sb=new Scanner(System.in);
		int swt;
		while(true) {
		System.out.println("Display menu:");
		System.out.println("1) Place Order\n"
				+ "2) Display Order\n"
				+"3) Exit");
		swt=sc.nextInt();
		switch(swt)
		{
		case 1:
			
			System.out.println("Enter the name of the customer: ");
	    	String name=sb.nextLine();
	    	System.out.println("Enter customer address: ");
	    	String add=sb.nextLine();
	    	System.out.println("Enter customer phone number: ");
	    	double phno=sc.nextDouble();
	    	System.out.println("Type of Pizza Topping preferred: "); 
	    	String topp=sb.nextLine();
	    	
	    	if(topp.equals("Mushroom")) {
	    		total=(350+tops.Mushroom.getValue())*1.04f;
	    		System.out.println("Price: "+total);
	    	}
	    	else if(topp.equals("Capsicum")) {
	    		total=(350+tops.Capsicum.getValue())*1.04f;
	    		System.out.println("Price: "+total);
	    	}
	    	else if(topp.equals("Jalapeno")) {
	    		total=(350+tops.Jalapeno.getValue())*1.04f;
	    		System.out.println("Price: "+total);
	    	}
	    	else if(topp.equals("Paneer")) {
	    		total=(350+tops.Paneer.getValue())*1.04f;
	    		System.out.println("Price: "+total);
	    	}
	    	else
	    		System.out.println("Invalid Topping choice");
	    		
	    	CustBean obj=new CustBean();
	    	
	    	System.out.println("Order Date:" +date);
	    	obj.setName(name);
	    	obj.setAddress(add);
	    	obj.setPhonenumber(phno);
	    	cust1.insert(obj);
	    	break;
	    	
		case 2:
			System.out.println("OrderId: ");
			int orderid=sc.nextInt();
			System.out.println("Total Price: "+total);
			System.out.println("Order Date:" +date);
			
		case 3:
			System.exit(0);
			
		default:
			System.out.println("Invalid choice");
		}
	}

}
}
