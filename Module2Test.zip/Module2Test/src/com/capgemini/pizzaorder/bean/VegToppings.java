package com.capgemini.pizzaorder.bean;

public class VegToppings {
	public enum vegToppings{Capsicum(30),Mushroom(50),Jalapeno(70),Paneer(85);
		
		private int value;  
		private vegToppings(int value){
			this.value=value;
		}
		public int getValue()
		{
			return value;
		}
		}  
		}  

