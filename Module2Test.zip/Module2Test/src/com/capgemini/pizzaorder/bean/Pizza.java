package com.capgemini.pizzaorder.bean;

public class Pizza {
	int pizzaid;
	int totalPrice;
	
}
